#pragma once
enum TiposArma
{
	Martillo, Hacha, Espada
};