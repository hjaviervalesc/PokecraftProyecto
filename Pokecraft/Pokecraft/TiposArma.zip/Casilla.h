#pragma once
#include "Pokemon.h"
#include <vector>

class Casilla
{

public:

	Pokemon* pokemon;
	Objeto* objeto;

	~Casilla();
};



