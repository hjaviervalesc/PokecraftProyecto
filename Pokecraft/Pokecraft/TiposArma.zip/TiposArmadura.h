#pragma once
enum TiposArmadura
{
	Casco, Mallas, Pechera
};
