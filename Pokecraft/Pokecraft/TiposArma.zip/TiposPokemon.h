#pragma once
enum TiposPokemon
{
	Fuego, Agua, Planta, Electrico
};