#pragma once
enum TiposObjeto
{
	BotiquinObjeto, Armas, Armadura
};