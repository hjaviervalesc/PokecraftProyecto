#include "Casilla.h"


Casilla::~Casilla()
{
	pokemon = nullptr;
	objeto = nullptr;
}